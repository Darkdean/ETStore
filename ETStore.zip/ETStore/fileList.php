<?php 

include_once("./config.inc.php");
session_start();
header("Content-type: text/html; charset=utf-8");

$htmlbody = "";
if($_SESSION['login']=="y"){
    
    $sql = "select * from storefile;";
	//1.新建PDO对象，连接数据库
	$dbh = new PDO($dsn, $dbuser, $dbpass);
	//关闭模拟预编译
	$dbh->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
	//设置字符集
	$dbh->exec('SET NAMES utf8');

	//2.预编译
	$sth = $dbh->prepare($sql);

	//4.执行sql
	$sth->execute();
	if ($sth->rowCount()){
		$table = "<div align='center'><table><tr><th>序号</th><th>名称</th><th>下载</th></tr>";
		while($arra = $sth->fetch(PDO::FETCH_ASSOC)){
			$table .= "<tr><td>".$arra['id']."</td><td>".$arra['filename']."</td><td><a href='./"
			.$arra['filepath']."'>下载</a></td></tr>";
		}
		$table .= "</table></div>";
		$htmlbody = $table;
	}else{
		$htmlbody = "暂无数据";
	}

    
} else {
    $htmlbody ="请先登录";
}

$htmlbody .= "<div align='center'><a href='./addFile.html'><font size='6px' color='pink'>添加文件</font></a></div>";

echo $htmlbody;

?>