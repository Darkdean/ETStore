<?php 

//$dsn = "mysql:dbname=etlab_store;host=127.0.0.1:8889";
$dsn = "mysql:dbname=etlab_store;host=127.0.0.1";
$dbuser = "root";
//$dbpass = "abcd1234";
$dbpass = "root";


?>