<?php 

$a = file_get_contents("./tmp/a706ac05cfbaac1e556d89c2dfba30d5");
echo $a;
?>