<?php 

header("Content-type: text/html; charset=utf-8");
session_start();

if($_SESSION['login']=="y"){
    extract($_GET);
    include($v.".php");
} else {
    echo "请先登录";
}

?>