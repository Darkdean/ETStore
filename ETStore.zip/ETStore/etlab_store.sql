/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50725
 Source Host           : 127.0.0.1:8889
 Source Schema         : etlab_store

 Target Server Type    : MySQL
 Target Server Version : 50725
 File Encoding         : 65001

 Date: 07/04/2021 14:06:05
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for storeapi
-- ----------------------------
DROP TABLE IF EXISTS `storeapi`;
CREATE TABLE `storeapi` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `apikey` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;


-- ----------------------------
-- Table structure for storefile
-- ----------------------------
DROP TABLE IF EXISTS `storefile`;
CREATE TABLE `storefile` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `filename` varchar(30) NOT NULL,
  `filepath` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `user` varchar(20) NOT NULL,
  `pass` varchar(32) NOT NULL,
  `level` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of users
-- ----------------------------
BEGIN;
INSERT INTO `users` VALUES (1, 'store_admin', 'e851da4d0e1403365281fd0f02e8f100', 0);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
