<?php 
header("Content-type: text/html; charset=utf-8");
include_once("./config.inc.php");

session_start();

if($_SESSION['login']=="y"){
    header("Location: ./mainpage.php?v=fileList");
    exit(0);
} else {
    $htmlbody = "";
    if(isset($_POST['user']) && strlen($_POST['user'])>0  && 
    isset($_POST['pass']) && strlen($_POST['pass'])>0){
		$user = $_POST['user'];
		$pass = md5($_POST['pass']);
		
		$sql = "select * from users where user=:user and pass=:pass";
		//1.新建PDO对象，连接数据库
		$dbh = new PDO($dsn, $dbuser, $dbpass);
		//关闭模拟预编译
		$dbh->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);

		//2.预编译
		$sth = $dbh->prepare($sql);

		//3.绑定参数
		$sth->bindValue(":user",$user);
		$sth->bindValue(":pass",$pass);

		//4.执行sql
		$sth->execute();
		if ($sth->rowCount()){
			$arra = $sth->fetch(PDO::FETCH_ASSOC);
			$_SESSION['id'] =$arra['id'];
			$_SESSION['level'] =$arra['level'];
			$_SESSION['login']  = "y";
			header("Location: ./mainpage.php?v=fileList");
			exit(0);
		}else{
			$htmlbody = "用户名或密码错误，请重试";
		}
    } else  {
        $htmlbody = "请输入用户名或密码后重试";
    }

    echo $htmlbody;
	exit(0);
}


?>