<?php
//没有开启session验证，可直接上传文件
include_once("./config.inc.php");
$uploaded_name = $_FILES['file']['name'];
$uploaded_ext  = substr($uploaded_name,strrpos( $uploaded_name,'.')+1);
if(strtolower($uploaded_ext) == "doc"
|| strtolower($uploaded_ext) == "docx"
|| strtolower($uploaded_ext) == "zip"
|| $_FILES["file"]["type"] == "doc"
|| $_FILES["file"]["type"] == "docx"
|| $_FILES["file"]["type"] == "zip")
{
	if (file_exists("./upload/" . $_FILES["file"]["name"]))
		{
			echo $_FILES["file"]["name"] . " already exists. ";
		} else {
			$md5time = md5(time());
			$tmpfile = "./tmp/".$md5time;
			move_uploaded_file($_FILES["file"]["tmp_name"],$tmpfile);

			//进行文件头检查
			$fp = fopen($tmpfile,"rb");
			$bindata = bin2hex(fread($fp,6));
			//echo $bindata."<br/>";
			if($bindata!=="504b03040a00" &&
				$bindata!=="d0cf11e0a1b1" &&
				$bindata!=="504b03041400"){
					fclose($fp);
					die("Invalid file..");
				}
			else {
				fclose($fp);
				//进行文件内容检测
				if(stripos(file_get_contents($tmpfile),"<?php")!==false){
					die("Dangerous file content..");
				} else {
					$filepath = "./upload/".$md5time.".".$uploaded_ext;
					$filename = pathinfo($_FILES['file']['name'], PATHINFO_FILENAME);
					rename($tmpfile,$filepath);
					@unlink($tmpfile);
					
					$sql = "insert into storefile(filename,filepath) values(:filename,:filepath)";
					//1.新建PDO对象，连接数据库
					$dbh = new PDO($dsn, $dbuser, $dbpass);
					//关闭模拟预编译
					$dbh->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
					//设置字符集
					$dbh->exec('SET NAMES utf8');
	
					//2.预编译
					$sth = $dbh->prepare($sql);
	
					//3.绑定参数
					$sth->bindValue(":filename",$filename);
					$sth->bindValue(":filepath",$filepath);
	
					//4.执行sql
					$sth->execute();
					if ($sth->rowCount()){
						echo "Store file successfully..";
					}else{
						echo "Store file failed..";
					}
				}
			}
		}
} else {
	echo "Invalid file..";
}
?>
